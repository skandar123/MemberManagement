package com.say.mms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MemberManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
